// Enhanced JavaScript functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the map with a more modern style
    function initMap() {
        const mapStyles = [
            {
                "featureType": "water",
                "elementType": "geometry",
                "stylers": [{"color": "#e9e9e9"}, {"lightness": 17}]
            },
            {
                "featureType": "landscape",
                "elementType": "geometry",
                "stylers": [{"color": "#f5f5f5"}, {"lightness": 20}]
            },
            // Add more custom styles here
        ];

        const mapOptions = {
            center: { lat: -34.397, lng: 150.644 },
            zoom: 8,
            styles: mapStyles,
            disableDefaultUI: true,
            zoomControl: true,
            mapTypeControl: false,
            scaleControl: true,
            streetViewControl: false,
            rotateControl: false,
            fullscreenControl: true
        };

        map = new google.maps.Map(document.getElementById('map'), mapOptions);
    }

    // Enhanced friend search with debouncing
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    const searchFriends = debounce((query) => {
        displaySearchResults(query);
    }, 300);

    // Improved search results display
    function displaySearchResults(query) {
        const searchResultsDiv = document.getElementById('searchResults');
        searchResultsDiv.innerHTML = '';

        if (!query) {
            searchResultsDiv.style.display = 'none';
            return;
        }

        const filteredFriends = friends.filter(friend => 
            friend.name.toLowerCase().includes(query.toLowerCase())
        );

        if (filteredFriends.length === 0) {
            searchResultsDiv.innerHTML = `
                <div class="p-4 text-center text-gray-600">
                    <p>No friends found matching "${query}"</p>
                    <button class="btn btn-sm btn-primary mt-2" onclick="showAddFriendModal()">
                        Add New Friend
                    </button>
                </div>
            `;
        } else {
            filteredFriends.forEach(friend => {
                const friendElement = document.createElement('div');
                friendElement.className = 'friend-card d-flex align-items-center';
                friendElement.innerHTML = `
                    <img src="${friend.avatar || 'https://via.placeholder.com/48'}" 
                         alt="${friend.name}" 
                         class="friend-avatar">
                    <div>
                        <h5 class="mb-1">${friend.name}</h5>
                        <p class="mb-0 text-muted">${friend.details}</p>
                    </div>
                `;
                searchResultsDiv.appendChild(friendElement);
            });
        }

        searchResultsDiv.style.display = 'block';
    }

    // Enhanced SOS functionality
    document.getElementById('sos').addEventListener('click', function() {
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(function(position) {
                const location = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                
                // Simulate sending SOS alert
                alert(`SOS alert sent! Your location: ${location.lat}, ${location.lng}`);
                
                // Add marker for SOS location
                new google.maps.Marker({
                    position: location,
                    map: map,
                    icon: {
                        path: google.maps.SymbolPath.CIRCLE,
                        scale: 10,
                        fillColor: '#ef4444',
                        fillOpacity: 1,
                        strokeWeight: 2,
                        strokeColor: '#fff'
                    },
                    animation: google.maps.Animation.BOUNCE
                });
                
                map.setCenter(location);
                map.setZoom(15);
            });
        }
    });

    // Initialize the map
    if (typeof google !== 'undefined') {
        initMap();
    }
});