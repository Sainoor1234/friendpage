import React, { useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import Testimonials from './components/Testimonials';
import Pricing from './components/Pricing';
import Contact from './components/Contact';
import Footer from './components/Footer';
import Chat from './components/Chat';
import Map from './components/Map';
import './index.css';

const mockFriends = [
  {
    id: '1',
    name: 'Sarah Johnson',
    location: { lat: 40.7128, lng: -74.0060 }
  },
  {
    id: '2',
    name: 'Michael Chen',
    location: { lat: 34.0522, lng: -118.2437 }
  },
  {
    id: '3',
    name: 'Jessica Williams',
    location: { lat: 51.5074, lng: -0.1278 }
  }
];

function App() {
  useEffect(() => {
    document.title = 'Innovate - Cutting-Edge Technology Solutions';
    document.documentElement.style.scrollBehavior = 'smooth';
  }, []);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
      <Header />
      <main>
        <Hero />
        <Features />
        <section className="py-16 bg-gray-50 dark:bg-gray-800">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-8">Find Friends Nearby</h2>
            <Map friends={mockFriends} />
          </div>
        </section>
        <Testimonials />
        <Pricing />
        <Contact />
      </main>
      <Footer />
      <Chat />
    </div>
  );
}

export default App;