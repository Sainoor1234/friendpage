import React, { useEffect, useRef } from 'react';
import { MapPin } from 'lucide-react';

interface MapProps {
  friends: Array<{
    id: string;
    name: string;
    location: {
      lat: number;
      lng: number;
    };
  }>;
}

const Map: React.FC<MapProps> = ({ friends }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const googleMapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);

  useEffect(() => {
    if (!mapRef.current) return;

    const mapOptions: google.maps.MapOptions = {
      center: { lat: 0, lng: 0 },
      zoom: 2,
      styles: [
        {
          featureType: 'water',
          elementType: 'geometry',
          stylers: [{ color: '#e9e9e9' }, { lightness: 17 }]
        },
        {
          featureType: 'landscape',
          elementType: 'geometry',
          stylers: [{ color: '#f5f5f5' }, { lightness: 20 }]
        },
        {
          featureType: 'road.highway',
          elementType: 'geometry.fill',
          stylers: [{ color: '#ffffff' }, { lightness: 17 }]
        }
      ],
      disableDefaultUI: true,
      zoomControl: true,
      mapTypeControl: false,
      scaleControl: true,
      streetViewControl: false,
      rotateControl: false,
      fullscreenControl: true
    };

    googleMapRef.current = new google.maps.Map(mapRef.current, mapOptions);

    return () => {
      markersRef.current.forEach(marker => marker.setMap(null));
      markersRef.current = [];
    };
  }, []);

  useEffect(() => {
    if (!googleMapRef.current) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    // Add markers for friends
    friends.forEach(friend => {
      const marker = new google.maps.Marker({
        position: friend.location,
        map: googleMapRef.current!,
        title: friend.name,
        animation: google.maps.Animation.DROP,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 10,
          fillColor: '#4f46e5',
          fillOpacity: 0.9,
          strokeWeight: 2,
          strokeColor: '#ffffff'
        }
      });

      const infoWindow = new google.maps.InfoWindow({
        content: `
          <div class="p-2">
            <h3 class="font-semibold">${friend.name}</h3>
            <p class="text-sm text-gray-600">Click to chat</p>
          </div>
        `
      });

      marker.addListener('click', () => {
        infoWindow.open(googleMapRef.current!, marker);
      });

      markersRef.current.push(marker);
    });
  }, [friends]);

  return (
    <div className="relative w-full h-[500px] rounded-xl overflow-hidden shadow-lg">
      <div ref={mapRef} className="w-full h-full" />
      <div className="absolute bottom-4 right-4">
        <button
          onClick={() => {
            if (navigator.geolocation) {
              navigator.geolocation.getCurrentPosition(
                (position) => {
                  const pos = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                  };
                  googleMapRef.current?.setCenter(pos);
                  googleMapRef.current?.setZoom(15);
                }
              );
            }
          }}
          className="bg-white p-2 rounded-lg shadow-md hover:bg-gray-50 transition-colors duration-300"
        >
          <MapPin className="h-5 w-5 text-blue-600" />
        </button>
      </div>
    </div>
  );
};

export default Map;